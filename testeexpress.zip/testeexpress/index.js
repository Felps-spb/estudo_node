
//imports dos frameworks 

import express from 'express';
import bodyParser from 'body-parser';
import { engine } from 'express-handlebars';
import Post from './models/Post.js';

//declaracao do express
const app = express();
const port = 8081;

// Configuração do Template Engine
app.engine('handlebars', engine({ defaultLayout: 'main' }));
app.set('view engine', 'handlebars');

// BodyParser
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Rotas:

//rota do main da pagina onde esta sendo exibido todas os itens do banco de dados

app.get('/', (req, res) => {
  Post.findAll({ order: [['id', 'DESC']] }) // Ordena os posts por ID em ordem decrescente
    .then(function (posts) {
      res.render('home', { posts: posts }); // puxa todos os posts do banco de dados
    })
    .catch(function (err) {
      res.status(500).send("Erro ao recuperar os posts: " + err.message); // exibe um erro no caso de exibicao ou ausencia de itens no banco
    });
});


app.get('/cad', (req, res) => res.render('formulario')); // rota de insercao de itens no banco de dados

app.post('/add', async (req, res) => { //pega os itens do formulario, envia para o banco e redireciona para pagina principal
  try {
    const { titulo, conteudo } = req.body; //cria as variaveis do formulario

    if (!titulo || !conteudo) {
      return res.status(400).send("Título e conteúdo são obrigatórios!"); //analisa se tem titulo e conteudo
    }

    await Post.create({ titulo, conteudo }); //caso tenha, ele cria o request para o banco de dados e envia os dados
    res.redirect('/') //redireciona para pagina principal
  } catch (err) {
    res.status(500).send("Houve um erro: " + err.message); //caso ocorra um erro, ele analisa tudo e envia uma mensagem
  }
});


app.get('/deletar/:id', (req, res) => { //deleta o post ordenado por id diretamente pelo button
  Post.destroy({ where: { 'id': req.params.id } })
    .then(function () {
      res.redirect('/')
    }).catch(function (err) {
      res.status(500).send("Erro ao deletar: " + err.message)
    })
})

// Iniciar servidor
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
