import { Sequelize, DataTypes, sequelize } from './db.js';

const Post = sequelize.define('postagens', {
    titulo: {
        type: DataTypes.STRING // Use DataTypes em vez de Sequelize.STRING
    },
    conteudo: {
        type: DataTypes.TEXT
    }
});

// Sincronizar o modelo 

/*

 Post.sync({ force: true })
    .then(() => {
        console.log('Tabela criada com sucesso!');
    })
    .catch((error) => {
        console.error('Erro ao criar a tabela:', error);
    }); 
    
*/

export default Post;