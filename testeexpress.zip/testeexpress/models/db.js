import { Sequelize, DataTypes } from 'sequelize';

const sequelize = new Sequelize('postapp', 'root', '', {
    host: "localhost",
    dialect: "mysql",
    query: { raw: true }
});

// Exportar o sequelize, Sequelize e DataTypes
export { sequelize, Sequelize, DataTypes };
